# Contenu
Ce dossier est destiné à accueillir les feuilles de style css.

Nous avons choisi de n'utiliser qu'un seul css et de le séprarer par section. Le css comporte 2 parties principales :
 * La 1ère partie contient les styles des entêtes, body et footer
 * La 2ème partie contient les styles des pages de chacun

TODO: Ajouter le style correspondant à votre page à la suite du css en précisant le titre de votre page.

