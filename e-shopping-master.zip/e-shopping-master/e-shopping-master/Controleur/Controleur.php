<?php

/**
 * Created by PhpStorm.
 * User: Nicolas Sobczak & Vincent Reynaert
 * Date: 21/10/2016
 */
interface Controleur
{
    /**
     * Fonction qui affiche la vue
     */
    public function getHTML();
}