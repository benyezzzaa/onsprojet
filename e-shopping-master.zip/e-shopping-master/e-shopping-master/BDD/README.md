# BDD
Ce dossier est destiné à accueillir les documents relatifs à la base de données.

## MLD
Le modèle logique de données est le fichier "databasePHPMyAdmin.png"

## Créer la base de données

Pour créer la base de donnée, il faut exécuter les instructions suivante:
- create database db_e_shopping; 
- use database db_e_shopping;
Il faut ensuite exécuter le fichier "db_e_shopping.sql".

En cas de besoin, l'instruction suivante permet de supprimer la base de données : drop database db_e_shopping;
