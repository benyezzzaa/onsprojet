<?php


interface Controleur
{
   
    public function getHTML();
}