var class_controleur_product_categorie =
[
    [ "__construct", "class_controleur_product_categorie.html#a095c5d389db211932136b53f25f39685", null ],
    [ "addProduitToPanier", "class_controleur_product_categorie.html#a52f2aed61cc5ab0f81ac1c2c2c7e528a", null ],
    [ "getHTML", "class_controleur_product_categorie.html#a5fc878ede54118176f912b557031ddd6", null ],
    [ "getProduit", "class_controleur_product_categorie.html#aa39b956895038a1e65f2a0ca81fd3398", null ],
    [ "setProduit", "class_controleur_product_categorie.html#ae8ce94e26e623d1c9017139ab9099bff", null ]
];