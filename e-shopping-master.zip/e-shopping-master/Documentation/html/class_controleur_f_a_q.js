var class_controleur_f_a_q =
[
    [ "__construct", "class_controleur_f_a_q.html#a095c5d389db211932136b53f25f39685", null ],
    [ "getHTML", "class_controleur_f_a_q.html#a5fc878ede54118176f912b557031ddd6", null ],
    [ "getQuestion", "class_controleur_f_a_q.html#aefe923d83ad382956235c7d5d0ed585f", null ],
    [ "getResearch", "class_controleur_f_a_q.html#a2af751da2790f7b0eee84c70d06afc87", null ],
    [ "handlerFAQ", "class_controleur_f_a_q.html#a04fb2c5e343872a9573f79585769ebbd", null ],
    [ "insertQuestion", "class_controleur_f_a_q.html#ae69aaac46d1c255051751164be0d09c8", null ],
    [ "insertReponse", "class_controleur_f_a_q.html#a7480a034ddac9d410b7077d58024399d", null ],
    [ "setQuestion", "class_controleur_f_a_q.html#af613c739ba7a1688696991c26acc2e84", null ]
];