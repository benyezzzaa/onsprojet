var class_controleur_inscription =
[
    [ "__construct", "class_controleur_inscription.html#a095c5d389db211932136b53f25f39685", null ],
    [ "getHTML", "class_controleur_inscription.html#a5fc878ede54118176f912b557031ddd6", null ],
    [ "getRegister", "class_controleur_inscription.html#a305da1141ea3140bfb32f71116fa74a0", null ],
    [ "getRegister_code", "class_controleur_inscription.html#a0307e539948d150bf09fbba5b47168ab", null ],
    [ "registerUser", "class_controleur_inscription.html#a1fdb0f05b888f4aa92b319775e488e70", null ],
    [ "setRegister", "class_controleur_inscription.html#a882fda813cdda97cda45fb328869f175", null ],
    [ "setRegister_code", "class_controleur_inscription.html#ad9f5a3353aaaff81959da9793c963655", null ]
];