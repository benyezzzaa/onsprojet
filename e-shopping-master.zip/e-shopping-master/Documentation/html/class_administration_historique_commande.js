var class_administration_historique_commande =
[
    [ "getAllPanier", "class_administration_historique_commande.html#a99a61cacbe9b864cf80e6a3a58cdd9df", null ],
    [ "getCommande", "class_administration_historique_commande.html#a975d5bf1677deceea4649fa149ec2c8f", null ],
    [ "getPanier", "class_administration_historique_commande.html#afea7457ce026ae1e25f7b0a5bbdf20e6", null ],
    [ "getPanierUser", "class_administration_historique_commande.html#a202bd01d794a3f5458c49b2eb7581a01", null ],
    [ "turnNotPaid", "class_administration_historique_commande.html#a8e7e7ae434f7feea0e1a79bd5b1ae5fb", null ],
    [ "turnPaid", "class_administration_historique_commande.html#a9ae74f94c3b10a7d50b785ab2b81d386", null ]
];