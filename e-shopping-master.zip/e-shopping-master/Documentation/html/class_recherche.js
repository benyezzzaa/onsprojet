var class_recherche =
[
    [ "getProduitByName", "class_recherche.html#abade96109735c7748cdc3964e5e4f38c", null ],
    [ "NO_RESULT", "class_recherche.html#abfbf185d9e7de47487c3dddb2c04dffd", null ]
];