var class_user_login =
[
    [ "connectUser", "class_user_login.html#a1534f7aff57af0309726ee4126aa5d1c", null ],
    [ "getUser", "class_user_login.html#a5cb9120cb9bb55a14b3c2427d22318f1", null ],
    [ "userExist", "class_user_login.html#a31d9501c9afa0cf622801e7f07fa2713", null ],
    [ "valid_password", "class_user_login.html#a99cafafbb80101063e758d6d037e1467", null ],
    [ "BAD_PASSWORD", "class_user_login.html#ab1504336ddd53ed15c390b7bbc0222b8", null ],
    [ "DATABASE_ERROR", "class_user_login.html#af34b223109162f12815ed33db507ac73", null ],
    [ "DOESNOT_EXIST", "class_user_login.html#a3f69a0c9def9fa58b727b9aea97ed474", null ],
    [ "FORM_INPUTS_ERROR", "class_user_login.html#af7c8b6b262d095770faef086c1690152", null ],
    [ "INVALID_MAIL_FORMAT", "class_user_login.html#a26d12f80ec1c4b70a5b9f8d2979ca60e", null ],
    [ "LOGIN_OK", "class_user_login.html#a64e88ed4dc3f1a760a4153e7a903e3a5", null ],
    [ "SALT_REGISTER", "class_user_login.html#a94e3070b350a34c0465c2f2e26af81d6", null ]
];