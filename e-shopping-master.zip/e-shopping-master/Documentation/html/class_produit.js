var class_produit =
[
    [ "createNewLignePanier", "class_produit.html#a98b1fa217af254f477a1a5e3f3b3a73b", null ],
    [ "createNewPanier", "class_produit.html#ac903e81ec85e4254f20e46f9ddf01d75", null ],
    [ "getAllProduit", "class_produit.html#a9cb09339d4aeb93b4d53b4f52340be25", null ],
    [ "getAllProduitsByCategorieId", "class_produit.html#a87692d9118b0daeb660b27c6902fd4fd", null ],
    [ "getCategories", "class_produit.html#a8729ba486702e7e12a3fff08965e1e7f", null ],
    [ "getLignePanier", "class_produit.html#a786590260bdb428efbcd0d4dac068720", null ],
    [ "getPanierForUser", "class_produit.html#a9033173ec91c8c98b73899be3bbd368c", null ],
    [ "getProduit", "class_produit.html#acd7c3d75bdfa4a96d35b075cb3870e21", null ],
    [ "increaseQuantityPanier", "class_produit.html#a582bf94a5adf1959c35f262e224bb02e", null ]
];