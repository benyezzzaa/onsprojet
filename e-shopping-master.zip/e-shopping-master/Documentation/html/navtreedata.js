var NAVTREE =
[
  [ "GeekProduct.com", "index.html", [
    [ "BDD", "md_BDD_README.html", null ],
    [ "Contenu", "md_Contenu_README.html", null ],
    [ "Controleur", "md_Controleur_README.html", null ],
    [ "Documentation", "md_Documentation_README.html", null ],
    [ "Images", "md_Images_README.html", null ],
    [ "Modele", "md_Modele_README.html", null ],
    [ "page listing", "md_page_listing.html", null ],
    [ "README", "md_README.html", null ],
    [ "Vue", "md_Vue_README.html", null ],
    [ "Data Structures", "annotated.html", [
      [ "Data Structures", "annotated.html", "annotated_dup" ],
      [ "Data Structure Index", "classes.html", null ],
      [ "Class Hierarchy", "hierarchy.html", "hierarchy" ],
      [ "Data Fields", "functions.html", [
        [ "All", "functions.html", null ],
        [ "Functions", "functions_func.html", null ]
      ] ]
    ] ]
  ] ]
];

var NAVTREEINDEX =
[
"annotated.html"
];

var SYNCONMSG = 'click to disable panel synchronisation';
var SYNCOFFMSG = 'click to enable panel synchronisation';