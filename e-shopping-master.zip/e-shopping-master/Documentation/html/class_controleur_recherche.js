var class_controleur_recherche =
[
    [ "__construct", "class_controleur_recherche.html#a095c5d389db211932136b53f25f39685", null ],
    [ "getHTML", "class_controleur_recherche.html#a5fc878ede54118176f912b557031ddd6", null ],
    [ "getRecherche", "class_controleur_recherche.html#ae03b9906195bb303e18c226a1e7e8129", null ],
    [ "getSearchModule", "class_controleur_recherche.html#a0ca39abb843fa7780c972446e6cb5664", null ],
    [ "setRecherche", "class_controleur_recherche.html#a8dd8e9e39c962752acc12139b2534a67", null ]
];