var class_administration_user =
[
    [ "deleteUser", "class_administration_user.html#a207ba21749d1c6d5dcee8276f793e937", null ],
    [ "getUser", "class_administration_user.html#a9b830dc85b8ad1f3b64f60e37c6b2cf3", null ],
    [ "getUserList", "class_administration_user.html#aeb20dee182d29e6d339cab9682b4ff04", null ],
    [ "updateUserStatus", "class_administration_user.html#a0a3754dcc8f94cd1230344f66446befb", null ]
];