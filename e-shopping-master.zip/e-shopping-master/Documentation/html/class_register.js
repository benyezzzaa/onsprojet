var class_register =
[
    [ "createNewUser", "class_register.html#a390d5eb557ffad56986a2507aad71dbf", null ],
    [ "userExist", "class_register.html#a31d9501c9afa0cf622801e7f07fa2713", null ],
    [ "ALREADY_EXIST", "class_register.html#a3913affb378b46e6bdea34f72bd4ccfe", null ],
    [ "DATABASE_ERROR", "class_register.html#af34b223109162f12815ed33db507ac73", null ],
    [ "FORM_INPUTS_ERROR", "class_register.html#af7c8b6b262d095770faef086c1690152", null ],
    [ "INVALID_MAIL_FORMAT", "class_register.html#a26d12f80ec1c4b70a5b9f8d2979ca60e", null ],
    [ "REGISTER_OK", "class_register.html#a7d6fea855224a6038a55ba7364990883", null ],
    [ "SALT_REGISTER", "class_register.html#a94e3070b350a34c0465c2f2e26af81d6", null ]
];