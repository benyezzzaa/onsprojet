var class_controleur_produit_list =
[
    [ "__construct", "class_controleur_produit_list.html#a095c5d389db211932136b53f25f39685", null ],
    [ "getHTML", "class_controleur_produit_list.html#a5fc878ede54118176f912b557031ddd6", null ],
    [ "getProduit", "class_controleur_produit_list.html#aa39b956895038a1e65f2a0ca81fd3398", null ],
    [ "setProduit", "class_controleur_produit_list.html#ae8ce94e26e623d1c9017139ab9099bff", null ]
];