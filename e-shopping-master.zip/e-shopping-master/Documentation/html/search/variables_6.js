var searchData=
[
  ['form_5finputs_5ferror',['FORM_INPUTS_ERROR',['../class_register.html#af7c8b6b262d095770faef086c1690152',1,'Register\FORM_INPUTS_ERROR()'],['../class_user_login.html#af7c8b6b262d095770faef086c1690152',1,'UserLogin\FORM_INPUTS_ERROR()']]]
];
