var searchData=
[
  ['login_5fok',['LOGIN_OK',['../class_user_login.html#a64e88ed4dc3f1a760a4153e7a903e3a5',1,'UserLogin']]]
];
