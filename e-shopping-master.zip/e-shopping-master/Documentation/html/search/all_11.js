var searchData=
[
  ['turnnotpaid',['turnNotPaid',['../class_administration_historique_commande.html#a8e7e7ae434f7feea0e1a79bd5b1ae5fb',1,'AdministrationHistoriqueCommande']]],
  ['turnpaid',['turnPaid',['../class_administration_historique_commande.html#a9ae74f94c3b10a7d50b785ab2b81d386',1,'AdministrationHistoriqueCommande']]]
];
