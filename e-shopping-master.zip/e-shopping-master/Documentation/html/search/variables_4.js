var searchData=
[
  ['database_5ferror',['DATABASE_ERROR',['../class_register.html#af34b223109162f12815ed33db507ac73',1,'Register\DATABASE_ERROR()'],['../class_user_login.html#af34b223109162f12815ed33db507ac73',1,'UserLogin\DATABASE_ERROR()']]],
  ['del_5fok',['DEL_OK',['../class_administration_produit.html#a28ad8cc6870458616e23d7a185c75ce0',1,'AdministrationProduit']]],
  ['does_5fnot_5fexist',['DOES_NOT_EXIST',['../class_administration_produit.html#ae1a025af762249e8cf83b1ade7f19c7e',1,'AdministrationProduit']]],
  ['doesnot_5fexist',['DOESNOT_EXIST',['../class_user_login.html#a3f69a0c9def9fa58b727b9aea97ed474',1,'UserLogin']]]
];
