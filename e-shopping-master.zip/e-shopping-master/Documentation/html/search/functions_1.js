var searchData=
[
  ['addproduit',['addProduit',['../class_controleur_administration_produit.html#a3980b865cc4b5db7b8ba5e737403cdd1',1,'ControleurAdministrationProduit']]],
  ['addproduittopanier',['addProduitToPanier',['../class_controleur_product_categorie.html#a52f2aed61cc5ab0f81ac1c2c2c7e528a',1,'ControleurProductCategorie']]]
];
