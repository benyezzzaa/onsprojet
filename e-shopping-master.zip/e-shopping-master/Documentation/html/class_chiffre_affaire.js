var class_chiffre_affaire =
[
    [ "getChiffreAffaire", "class_chiffre_affaire.html#ae80ec07d9ad4fddec5622ad431d2d1b3", null ]
];